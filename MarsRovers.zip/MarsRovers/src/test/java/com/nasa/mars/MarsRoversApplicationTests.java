package com.nasa.mars;

import static org.junit.jupiter.api.Assertions.assertEquals;

import java.util.LinkedList;
import java.util.Queue;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import com.nasa.mars.controller.MarsRoverController;
import com.nasa.mars.model.Rover;

class MarsRoversApplicationTests {

	
	private MarsRoverController contorller = new MarsRoverController();
	private Queue<String> data = new LinkedList<String>();
	
	
	@BeforeEach
	public void beforeEach() {
		contorller = new MarsRoverController();
		data = new LinkedList<String>();
	}
	

	@Test
	public void createRover_ValidLocation_ShouldSucceed() {
		data.add("5 5");
		data.add("1 2 N");
		data.add("LMLMLMLMM");
		contorller.loadData(data);
		Queue<Rover> allRovers = contorller.getPlateau().getAllRovers();
		Rover firstRover = allRovers.remove();
		assertEquals("1 2 N", firstRover.currentStatus());
	}
	
	
	@Test
	public void createTwoRovers_ValidLocations_ShouldSucceed() {
		data.add("5 5");
		data.add("1 2 N");
		data.add("LMLMLMLMM");
		data.add("2 4 W");
		data.add("LMLMRRRMM");
		contorller.loadData(data);
		Queue<Rover> allRovers = contorller.getPlateau().getAllRovers();
		Rover firstRover = allRovers.remove();
		Rover secondRover = allRovers.remove();
		assertEquals("1 2 N", firstRover.currentStatus());
		assertEquals("2 4 W", secondRover.currentStatus());
	}

	
	@Test
	public void createRover_InValidLocation_ShouldFail() {
		data.add("5 5");
		data.add("9 9 N");
		data.add("LMLMLMLMM");
		try {
			contorller.loadData(data);
		}
		catch(Exception ex) {
				assertEquals("Invalid Poition - Postion off the Plateau: 'Position [x=9, y=9]'", ex.getMessage());
		}
	}
	
	
	@Test
	public void createTwoRovers_OnTopOfEachother_ShouldFail() {
		data.add("5 5");
		data.add("1 2 N");
		data.add("LMLMLMLMM");
		data.add("1 2 N");
		data.add("LMLMRRRMM");
		try {
			contorller.loadData(data);
		}
		catch(Exception ex) {
				assertEquals("Invalid Poition - Already occupies by another Rover: 'Position [x=1, y=2]'", ex.getMessage());
		}
	}
	
	

	@Test
	public void createTwoRovers_ValidMovesSpin_ShouldSucceed() {
		data.add("5 5");
		data.add("1 2 N");
		data.add("LMLM");
		data.add("2 4 W");
		data.add("RMRM");
		contorller.loadData(data);
		contorller.runAllInstructions();
		Queue<Rover> allRovers = contorller.getPlateau().getAllRovers();
		Rover firstRover = allRovers.remove();
		Rover secondRover = allRovers.remove();
		assertEquals("0 1 S", firstRover.currentStatus());
		assertEquals("3 5 E", secondRover.currentStatus());
	}
	

	@Test
	public void createRover_WillNotMoveNorthOffBoard_ShouldSucceed() {
		data.add("5 5");
		data.add("5 5 N");
		data.add("M");
		contorller.loadData(data);
		try {
			contorller.runAllInstructions();
		}
		catch(Exception ex) {
			assertEquals("Invalid Poition - Postion off the Plateau: 'Position [x=5, y=6]'", ex.getMessage());
		}
	}
	

	@Test
	public void createRover_WillNotMoveSouthOffBoard_ShouldSucceed() {
		data.add("5 5");
		data.add("0 0 S");
		data.add("M");
		contorller.loadData(data);
		try {
			contorller.runAllInstructions();
		}
		catch(Exception ex) {
			assertEquals("Invalid Poition - Postion off the Plateau: 'Position [x=0, y=-1]'", ex.getMessage());
		}
	}
	

	@Test
	public void createRover_WillNotMoveEastOffBoard_ShouldSucceed() {
		data.add("5 5");
		data.add("5 5 E");
		data.add("M");
		contorller.loadData(data);
		try {
			contorller.runAllInstructions();
		}
		catch(Exception ex) {
			assertEquals("Invalid Poition - Postion off the Plateau: 'Position [x=6, y=5]'", ex.getMessage());
		}
	}
	

	@Test
	public void createRover_WillNotMoveWestOffBoard_ShouldSucceed() {
		data.add("5 5");
		data.add("0 0 W");
		data.add("M");
		contorller.loadData(data);
		try {
			contorller.runAllInstructions();
		}
		catch(Exception ex) {
			assertEquals("Invalid Poition - Postion off the Plateau: 'Position [x=-1, y=0]'", ex.getMessage());
		}
	}
	
	
	
	//TODO - other tests too add
	//Bad File Name
	//Good File Name
	//Populate large map correctly
	//Bad Instructions
	//Bad Move
	//Bad Header

}
