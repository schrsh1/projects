package com.nasa.mars.model;


/**
 * The Class Position.
 */
public class Position {


	/** TheCoordinates */
	private int x;
	private int y; 
	
	
	/**
	 * Instantiates a new position.
	 *
	 * @param pIntialXPosition the initial X position
	 * @param pIntialYPosition the initial Y position
	 */
	public Position(int pInitialXPosition, int pInitialYPosition) {
		x = pInitialXPosition;
		y = pInitialYPosition;
	}
	

	/**
	 * Gets the description.
	 *
	 * @return the description
	 */
	public String getDescription() {
		String location = x + " " + y;
		return location;
	}
	
	

	
	/**
	 * Create a Position using the Move and Heading direction
	 *
	 * @param pHeading the heading
	 * @param pMove the move
	 * @return the position
	 */
	public Position createProposedPosition(Heading pHeading, Move pMove) {
		int proposedX = x;
		int proposedY = y;
		if(pMove.getInstruction().equals(Move.FORWARD)) {
			if(pHeading.getDirection().equals(Heading.NORTH)) {
				proposedY = y + 1;
			}
			else if(pHeading.getDirection().equals(Heading.EAST)) {
				proposedX = x + 1;
			}
			else if(pHeading.getDirection().equals(Heading.SOUTH)) {
				proposedY = y - 1;
			}
			else if(pHeading.getDirection().equals(Heading.WEST)) {
				proposedX = x - 1;
			}
		}
		return new Position(proposedX , proposedY);
	}

	
	
	
	
	/**
	 * Gets the x.
	 *
	 * @return the x
	 */
	public int getX() {
		return x;
	}


	/**
	 * Sets the x.
	 *
	 * @param x the new x
	 */
	public void setX(int x) {
		this.x = x;
	}


	/**
	 * Gets the y.
	 *
	 * @return the y
	 */
	public int getY() {
		return y;
	}


	/**
	 * Sets the y.
	 *
	 * @param y the new y
	 */
	public void setY(int y) {
		this.y = y;
	}
	
	



	/**
	 * Equals.
	 *
	 * @param obj the obj
	 * @return true, if successful
	 */
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Position other = (Position) obj;
		if (x != other.x)
			return false;
		if (y != other.y)
			return false;
		return true;
	}
	

	/**
	 * Hash code.
	 *
	 * @return the int
	 */
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + x;
		result = prime * result + y;
		return result;
	}


	/**
	 * To string.
	 *
	 * @return the string
	 */
	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder();
		builder.append("Position [x=");
		builder.append(x);
		builder.append(", y=");
		builder.append(y);
		builder.append("]");
		return builder.toString();
	}
}
