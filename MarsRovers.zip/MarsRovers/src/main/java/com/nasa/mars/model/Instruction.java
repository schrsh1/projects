package com.nasa.mars.model;


/**
 * The Class Instruction.
 */
public abstract class Instruction {
	
	/**
	 * Gets the instruction.
	 *
	 * @return the instruction
	 */
	public abstract String getInstruction(); 
}
