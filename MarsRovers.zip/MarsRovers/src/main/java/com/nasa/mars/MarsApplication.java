package com.nasa.mars;

import com.nasa.mars.controller.MarsRoverController; 


/**
 * The Class MarsApplication.
 */
public class MarsApplication {
	
	
	/**
	 * The main method.
	 *
	 * @param args the arguments
	 */
	public static void main(String[] args) {
		
		MarsRoverController controller = new MarsRoverController();
		boolean success = controller.populateWithTextFile("MarsRoverTextFile_1.txt");
		if(success) {
			controller.runAllInstructions();
			controller.displayCurrentStatus();
		}
		else {
			System.out.println("Could not load file.  Application terminated.");
		}
	}

}
