package com.nasa.mars.model;

import java.util.LinkedList;
import java.util.Queue;


/**
 * The Class Rover.
 */
public class Rover {
	
	/** The Constant RAW_X_COORDINATE_INDEX. */
	public static final int RAW_X_COORDINATE_INDEX = 0;
	
	/** The Constant RAW_Y_COORDINATE_INDEX. */
	public static final int RAW_Y_COORDINATE_INDEX = 1;
	
	/** The Constant RAW_HEADING_INDEX. */
	public static final int RAW_HEADING_INDEX = 2;
	
	/** The plateau. */
	private Plateau plateau;
	
	/** The position. */
	private Position position;




	/** The heading. */
	private Heading heading;
	
	/** The all instructions. */
	private Queue<Instruction> allInstructions;
	

	/** The raw init coordinates and heading. */
	// Saved for testing
	private String rawInitCoordinatesAndHeading;
	
	/** The raw instructions. */
	private String rawInstructions;
	
	/**
	 * Instantiates a new rover.
	 *
	 * @param pRawInitCoordinatesAndHeading the raw init coordinates and heading
	 * @param pRawInstructions the raw instructions
	 * @param pPlateau the plateau
	 */
	public Rover(String pRawInitCoordinatesAndHeading, String pRawInstructions, Plateau pPlateau) {
		plateau = pPlateau; 
		rawInitCoordinatesAndHeading = pRawInitCoordinatesAndHeading.trim();
		rawInstructions = pRawInstructions.trim();
		initializePositionAndHeading();
		initializeInstructions();
	}
	
	
	/**
	 * Run instructions.
	 */
	public void runInstructions() {
		for(Instruction currInstruction : allInstructions) {
			if(currInstruction instanceof Move) {
				executeMove((Move)currInstruction);
			}
			if(currInstruction instanceof Spin) {
				executeSpin((Spin)currInstruction);
			}
		}
	}
	

	/**
	 * Execute spin.
	 *
	 * @param pSpin the spin
	 */
	private void executeSpin(Spin pSpin) {
		heading.updateDirection(pSpin);
	}
	
	
	/**
	 * Execute move.
	 *
	 * @param pMove the move
	 */
	private void executeMove(Move pMove) {
		Position proposedPosition = position.createProposedPosition(heading, pMove);
		boolean isValidPosition = plateau.validateNewPosition(proposedPosition);
		if(isValidPosition) {
			position.setX(proposedPosition.getX());
			position.setY(proposedPosition.getY());
		}
	}
	
	
	
	
	
	
	
	/**
	 * Current status.
	 *
	 * @return the string
	 */
	public String currentStatus() {
		return position.getDescription() + " " + heading.getDirection();
	}
	
	
	
	/**
	 * Initialize position and heading given the raw text data
	 */
	private void initializePositionAndHeading(){
		String[] coordinatesAndHeader = rawInitCoordinatesAndHeading.split(" ");
		int initialXPosition = Integer.parseInt(coordinatesAndHeader[RAW_X_COORDINATE_INDEX]);
		int initialYPosition  = Integer.parseInt(coordinatesAndHeader[RAW_Y_COORDINATE_INDEX]);
		String initalHeading = coordinatesAndHeader[RAW_HEADING_INDEX];
		
		// Create initial position
		Position proposedPosition = new Position(initialXPosition, initialYPosition);
		boolean isValidPosition = plateau.validateNewPosition(proposedPosition);
		if(isValidPosition) {
			position = proposedPosition;
		}
		
		// Create initial heading
		heading = new Heading(initalHeading);
	}

	
	
	
	/**
	 * Initialize instructions.
	 */
	private void initializeInstructions() {
		allInstructions = new LinkedList<Instruction>();
		for (String curr: rawInstructions.split("")) {
			if( curr.equals(Spin.LEFT) ||
				curr.equals(Spin.RIGHT) ) 
			{
				Instruction currInstruction = new Spin(curr);
				allInstructions.add(currInstruction);
			}
			else if(curr.equals(Move.FORWARD)) {
				Instruction currInstruction = new Move(curr);
				allInstructions.add(currInstruction);
			}
			else {
				throw new RuntimeException("Cannot create Instruction using invalid Instruction value: '" + curr + "' from rawInstructions: '" + rawInstructions + "'");
			}
		}
	}
	

	/**
	 * Gets the position.
	 *
	 * @return the position
	 */
	public Position getPosition() {
		return position;
	}
	
}
