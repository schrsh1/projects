package com.nasa.mars.controller;

import java.io.FileNotFoundException;
import java.util.LinkedList;
import java.util.Queue;

import com.nasa.mars.model.Plateau;
import com.nasa.mars.model.Rover;
import com.nasa.mars.service.MarsRoverService;



/**
 * The Class MarsRoverContoller.
 */
public class MarsRoverController {
	
	/** The plateau. */
	private Plateau plateau;

	/** The service. */
	private MarsRoverService service;
	
	
	/**
	 * Instantiates a new mars rover controller.
	 */
	public MarsRoverController() {
		service = new MarsRoverService(); 
	}
	
	
	/**
	 * Populate with text file.
	 *
	 * @param fileName the file name
	 * @return true, if successful
	 */
	public boolean populateWithTextFile(String fileName){
		try {
			Queue<String> data = service.getAllDataFromTextFile(fileName);
			loadData(data);
		} catch (FileNotFoundException e) {
			e.printStackTrace();
			return false;
		}
		
		return true;
	}
	
	
	/**
	 * Load data.
	 *
	 * @param data the data
	 * @return true, if successful
	 */
	public boolean loadData(Queue<String> data) {
		try {
			String rawUpperRightCoordinates = data.remove().trim();
			Queue<Rover> allRovers = new LinkedList<Rover>();
			plateau = new Plateau(rawUpperRightCoordinates, allRovers);
			while(  !data.isEmpty() ) {
				String rawInitCoordinatesAndHeading = data.remove();
				String rawInstructions = data.remove().trim();
				Rover currentRover = new Rover(rawInitCoordinatesAndHeading, rawInstructions, plateau);
				allRovers.add(currentRover);
			}
		}
		catch(Exception e) {
			e.printStackTrace();
			return false;
		}
		
		
		return true;
	}
	
	
	
	/**
	 * Run all instructions.
	 */
	public void runAllInstructions() {
		for(Rover currRover : plateau.getAllRovers()) {
			currRover.runInstructions();
		}
	}
	
	
	
	/**
	 * Display current status.
	 */
	//Return String Representation of coordinates and heading
	public void displayCurrentStatus() {
		for(Rover currRover : plateau.getAllRovers()) {
			System.out.println(currRover.currentStatus());
		}
	}
	

	/**
	 * Gets the plateau.
	 *
	 * @return the plateau
	 */
	public Plateau getPlateau() {
		return plateau;
	}

}
