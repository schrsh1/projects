package com.nasa.mars.model;


/**
 * The Class Heading.
 */
public class Heading {
	
	
	/** The Constant NORTH. */
	public static final String NORTH = "N";
	
	/** The Constant EAST. */
	public static final String EAST = "E";
	
	/** The Constant SOUTH. */
	public static final String SOUTH = "S";
	
	/** The Constant WEST. */
	public static final String WEST = "W";
	
	
	
	/** The direction of this Header */
	private String direction; 
	
	
	
	/**
	 * Instantiates a new heading.
	 *
	 * @param pValue the direction value
	 */
	public Heading(String pValue) {
		setDirection(pValue);
	}

	
	/**
	 * Update direction depending on 
	 * 	pSpin and current direction
	 *
	 * @param pSpin the spin
	 */
	public void updateDirection(Spin pSpin) {
		if(pSpin.getInstruction().equals(Spin.RIGHT)) {
			if(direction.equals(NORTH)) {
				direction = EAST;
			}
			else if(direction.equals(EAST)) {
				direction = SOUTH;
			}
			else if(direction.equals(SOUTH)) {
				direction = WEST;
			}
			else if(direction.equals(WEST)) {
				direction = NORTH;
			}
		}
		else if(pSpin.getInstruction().equals(Spin.LEFT)) {
			if(direction.equals(NORTH)) {
				direction = WEST;
			}
			else if(direction.equals(WEST)) {
				direction = SOUTH;
			}
			else if(direction.equals(SOUTH)) {
				direction = EAST;
			}
			else if(direction.equals(EAST)) {
				direction = NORTH;
			}
		}
	}
	

	/**
	 * Sets the direction.
	 *
	 * @param pValue the new direction
	 */
	public void setDirection(String pValue) {
		if( NORTH.equals(pValue) ||
			SOUTH.equals(pValue) ||
			EAST.equals(pValue) ||
			WEST.equals(pValue) ) 
		{
			direction = pValue;
		}
		else {
			throw new RuntimeException("Cannot create Heading using invalid Heading value: '" + pValue + "'");
		}
	}

	
	/**
	 * Gets the direction.
	 *
	 * @return the direction
	 */
	public String getDirection() {
		return direction;
	}
	
}
