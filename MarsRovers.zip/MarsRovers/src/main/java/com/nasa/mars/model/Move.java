package com.nasa.mars.model;


/**
 * The Class Move.
 */
public class Move extends Instruction{

	/** The Constant FORWARD. */
	public static final String FORWARD = "M";
	
	/** The move instruction. */
	private String moveInstruction;
	
	
	/**
	 * Instantiates a new move.
	 *
	 * @param pMoveInstruction the move instruction
	 */
	public Move(String pMoveInstruction) {
		setInstruction(pMoveInstruction); 
	}

	
	/**
	 * Sets the instruction.
	 *
	 * @param pMoveInstruction the new instruction
	 */
	private void setInstruction(String pMoveInstruction) {
		if( FORWARD.equals(pMoveInstruction)){
			moveInstruction = pMoveInstruction;
		}
		else {
			throw new RuntimeException("Cannot create Move using invalid Move value: '" + pMoveInstruction + "'");
		}
	}
	
	
	/**
	 * Gets the instruction.
	 *
	 * @return the instruction
	 */
	@Override
	public String getInstruction() {
		return moveInstruction;
	}

}
