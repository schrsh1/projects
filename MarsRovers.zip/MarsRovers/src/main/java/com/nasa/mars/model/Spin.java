package com.nasa.mars.model;


/**
 * The Class Spin.
 */
public class Spin extends Instruction {

	/** The Constant LEFT. */
	public static final String LEFT = "L";
	
	/** The Constant RIGHT. */
	public static final String RIGHT = "R";
	
	/** The spin instruction. */
	private String spinInstruction;

	/**
	 * Instantiates a new spin.
	 *
	 * @param pSpinInstruction the spin instruction
	 */
	public Spin(String pSpinInstruction) {
		setInstruction(pSpinInstruction);
	}

	/**
	 * Sets the instruction.
	 *
	 * @param pSpinInstruction the new instruction
	 */
	private void setInstruction(String pSpinInstruction) {
		if( LEFT.equals(pSpinInstruction) ||
			RIGHT.equals(pSpinInstruction) ) 
		{
			spinInstruction = pSpinInstruction;
		}
		else { 
			throw new RuntimeException("Cannot create Spin using invalid Sping value: '" + pSpinInstruction + "'");
		}
	}

	/**
	 * Gets the instruction.
	 *
	 * @return the instruction
	 */
	@Override
	public String getInstruction() {
		return spinInstruction;
	}
	
}
