package com.nasa.mars.service;

import java.io.FileNotFoundException;
import java.util.Queue;

import com.nasa.mars.repository.TextFileRepository;


/**
 * The Class MarsRoverService.
 */
public class MarsRoverService {
	
	
	/** The repository. */
	TextFileRepository repository;

	/**
	 * Instantiates a new mars rover service.
	 */
	public MarsRoverService() {
		repository = new TextFileRepository();
	}

	
	/**
	 * Gets the all data from text file.
	 *
	 * @param fileName the file name
	 * @return the all data from text file
	 * @throws FileNotFoundException the file not found exception
	 */
	public Queue<String> getAllDataFromTextFile(String fileName) throws FileNotFoundException {
		return repository.getAllDataFromTextFile(fileName);
	}

}
