package com.nasa.mars.repository;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.LinkedList;
import java.util.Queue; 
import java.util.Scanner;


/**
 * The Class TextFileRepository.
 */
public class TextFileRepository {
	

	/**
	 * Gets the all data from text file.
	 *
	 * @param fileName the file name
	 * @return the all data from text file
	 * @throws FileNotFoundException the file not found exception
	 */
	public Queue<String> getAllDataFromTextFile(String fileName) throws FileNotFoundException{
		Queue<String> dataToReturn = new LinkedList<String>();
		File textFile = new File(fileName);
		Scanner scanner = null;
		try {
			scanner = new Scanner(textFile);
	        while(scanner.hasNextLine()){
	            String line = scanner.nextLine();
	            dataToReturn.add(line);
	        }      
		}
		finally {
			if(scanner != null) {
				scanner.close();
			}
		}
		return dataToReturn;
	}

}
