package com.nasa.mars.model;

import java.util.Queue;


/**
 * The Class Plateau.
 */
public class Plateau {
	

	/** The Constant RAW_UPPER_X_COORDINATE_INDEX. */
	public static final int RAW_UPPER_X_COORDINATE_INDEX = 0;
	
	/** The Constant RAW_UPPER_Y_COORDINATE_INDEX. */
	public static final int RAW_UPPER_Y_COORDINATE_INDEX = 1;
	
	/** The upper X. */
	// Upper and lower max coordinates
	private final int upperX;
	
	/** The upper Y. */
	private final int upperY;
	
	/** The lower X. */
	private final int lowerX = 0; 
	
	/** The lower Y. */
	private final int lowerY = 0;
	
	/** All associated Rovers */
	private Queue<Rover> allRovers;



	/** Saved for testing - The raw upper right coordinates. */
	private final String rawUpperRightCoordinates;
	
	
	/**
	 * Instantiates a new plateau.
	 * Constructor for immutable class
	 *
	 * @param pRawUpperRightCoordinates the raw upper right coordinates
	 * @param pAllRovers describes all rovers
	 */
	public Plateau(String pRawUpperRightCoordinates, Queue<Rover> pAllRovers){
		allRovers = pAllRovers;
		rawUpperRightCoordinates = pRawUpperRightCoordinates.trim();
		String[] coordinates = rawUpperRightCoordinates.split(" ");
		upperX = Integer.parseInt(coordinates[RAW_UPPER_X_COORDINATE_INDEX]);
		upperY = Integer.parseInt(coordinates[RAW_UPPER_Y_COORDINATE_INDEX]);
	}

	
	
	/**
	 * Validate the new position.
	 * Make sure the new Position in on the map 
	 * 	and does not run into another Rover
	 *
	 * @param proposedPosition the proposed position
	 * @return true, if successful
	 */
	public boolean validateNewPosition(Position proposedPosition) {
		if( proposedPosition.getX() > upperX ||
			proposedPosition.getX() < lowerX ||
			proposedPosition.getY() > upperY ||
			proposedPosition.getY() < lowerY  ) 
		{
			throw new RuntimeException("Invalid Poition - Postion off the Plateau: '" + proposedPosition.toString() + "'");
		}
		else {
			for(Rover currRover : allRovers) {
				if(currRover.getPosition().equals(proposedPosition)){
					throw new RuntimeException("Invalid Poition - Already occupies by another Rover: '" + proposedPosition.toString() + "'");
				}
			}
		}
		
		return true;
	}
	
	
	
	
	/**
	 * Gets the upper X.
	 *
	 * @return the upper X
	 */
	public int getUpperX() {
		return upperX;
	}
	
	/**
	 * Gets the all rovers.
	 *
	 * @return the all rovers
	 */
	public Queue<Rover> getAllRovers() {
		return allRovers;
	}
	
	/**
	 * Gets the upper Y.
	 *
	 * @return the upper Y
	 */
	public int getUpperY() {
		return upperY;
	}
	
	/**
	 * Gets the lower X.
	 *
	 * @return the lower X
	 */
	public int getLowerX() {
		return lowerX;
	}
	
	/**
	 * Gets the lower Y.
	 *
	 * @return the lower Y
	 */
	public int getLowerY() {
		return lowerY;
	}
	
	/**
	 * Gets the raw upper right coordinates.
	 *
	 * @return the raw upper right coordinates
	 */
	public String getRawUpperRightCoordinates() {
		return rawUpperRightCoordinates;
	}



	/**
	 * To string.
	 *
	 * @return the string
	 */
	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder();
		builder.append("Plateau [upperX=");
		builder.append(upperX);
		builder.append(", upperY=");
		builder.append(upperY);
		builder.append(", lowerX=");
		builder.append(lowerX);
		builder.append(", lowerY=");
		builder.append(lowerY);
		builder.append(", rawUpperRightCoordinates=");
		builder.append(rawUpperRightCoordinates);
		builder.append("]");
		return builder.toString();
	}
	
}
